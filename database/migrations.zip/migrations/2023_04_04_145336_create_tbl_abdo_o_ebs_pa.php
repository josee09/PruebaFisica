<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('tbl_abdo_o_ebr_pa', function (Blueprint $table) {
            $table->id();
            $table->integer('repeticiones');
            $table->integer('edad');
            $table->integer('nota_mas');
            $table->integer('nota_fem');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('tbl_abdo_o_ebr');
    }
};
