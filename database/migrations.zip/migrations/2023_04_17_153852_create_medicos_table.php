<?php
   // 17-4-23 creación de migración
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()//estructura y creacion de la tabla de registros de evaluacion medica para el personal policial 
    {
        Schema::create('medicos', function (Blueprint $table) {
            $table->id();
            $table->string('periodo', 15); //periodo ordinario/extraordianrio
            $table->string('precion', 6); //presion alterial 
            $table->string('altura', 4); //altura en centimetro
            $table->string('medabdo', 6);  //medidda de abdominales en pulgadas
            $table->string('medcuello', 6); //medida de cuello en pulgadas
            $table->string('medabdcue', 6);//calculo de variable de abdomen/cuello
            $table->string('facabdcuell', 6); //factor de abdomen/cuello
            $table->string('facalt', 6); //factor de altura
            $table->string('porcgrasa', 6);//porcentaje de grasa coorporal
            $table->string('estandar', 3); //medida establecida mediante acuerdo de gaceta
            $table->string('peso', 3);  //peso en libras
            $table->string('pesoideal', 6); //peso sobre calculo de peso que debe poseer la persona 
            $table->string('expeso', 6); //peso extra que posee sea mayor o menor a ideal
            $table->string('condicion', 30); //condion de personal sobre peso o falta de peso
            $table->text('obs', 100);//observaciones sobre evalaucion medica 
            $table->string('medico', 60); //nombre de medico evaludor
            $table->string('grado', 30); //grado del medico evaluador
            $table->unsignedBigInteger('id_evaluado'); // id traido de trabla evaluado
            $table->foreign('id_evaluado')->references('id')->on('evaluados');
            $table->timestamps();
        });
    }

    
    public function down()
    {
        Schema::dropIfExists('medicos');
    }
};
