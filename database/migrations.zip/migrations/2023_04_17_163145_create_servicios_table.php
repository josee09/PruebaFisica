<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('servicios', function (Blueprint $table) {
            $table->id();
            $table->string('fbrazo', 3)->nullable();  //numero de repeticiones de flexiones de brazo
            $table->string('nfbrazo', 3)->nullable(); //nota de flexiones
            $table->string('fabdomen', 3)->nullable(); //numero de repeticiones de abdominales
            $table->string('nfabdomen', 3)->nullable();// nota de abdominales
            $table->string('carrera', 6)->nullable(); //tiempó de la carrera
            $table->string('ncarrera', 6)->nullable(); //nota de carrera
            $table->string('natacion', 6)->nullable();//tiempo de natacion
            $table->string('nonatacion', 6)->nullable();//nota de natacion
            $table->string('caminata', 6)->nullable();//tiempo de caminata
            $table->string('nocaminata', 6)->nullable();//nota de caminata
            $table->string('ciclismo', 6)->nullable(); //tiempo de ciclismo
            $table->string('nociclismo', 6)->nullable();// nota de ciclismo
            $table->string('barra', 6)->nullable(); // //numero de repeticiones de barra
            $table->string('nobarra', 6)->nullable(); //nota de barra
            $table->string('edad', 3);
            $table->string('ranedad', 6); //rango de edad
            $table->string('oficialjefe', 40); //oficial a cargo de la evaluacion
            $table->string('valuador1', 40);
            $table->string('valuador2', 40);
            $table->string('valuador3', 40);
            $table->string('valuador4', 40); //evaluadores de la prueba
            $table->string('exsp', 3)->nullable(); //sub total
            $table->string('nmenos_exp', 6)->nullable(); //sb menos libras de exceso
            $table->string('nfinal', 5); //nota final
            $table->text('obs', 100); //campo de observacion de evalucion
            $table->text('docobs', 100); //imagen de comprobante medico
            $table->unsignedBigInteger('id_evaluado');
            $table->foreign('id_evaluado')->references('id')->on('evaluados');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('servicios');
    }
};
