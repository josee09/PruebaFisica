<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('tbl_caminata', function (Blueprint $table) {
            $table->id();
            $table->string('tiempo',5);
            $table->integer('edad',2);
            $table->integer('nota_mas',3);
            $table->integer('nota_fem',3);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('tbl_caminata');
    }
};
