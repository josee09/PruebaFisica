<?php
// 17-4-23 creación de migración

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up() //estructura y creacion de la tabla de registros personales para el personal policial 
    {
        Schema::create('evaluados', function (Blueprint $table) {
            $table->id();
            $table->string('nombre', 30);
            $table->string('apellido', 30);
            $table->string('dni', 13)->unique();
            $table->string('lugarasig', 100);
            $table->string('serie', 10);
            $table->string('grado', 30);
            $table->date('fechanac', 30);
            $table->string('promocion', 10);
            $table->string('sexo', 3);
            $table->timestamps();
        });
    } 

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('evaluados');
    }
};

